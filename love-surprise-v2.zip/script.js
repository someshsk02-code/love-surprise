function go(){p1.style.display='none';p2.style.display='block';}
function pick(){alert('Beautiful choice! ❤️');}